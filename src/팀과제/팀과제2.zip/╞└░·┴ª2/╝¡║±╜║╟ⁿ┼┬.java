package 팀과제.팀과제2;

public class 서비스형태 {
    String 이름;
    String 용량;
    String 사용인원;
    int 금액;

    서비스형태(String 이름, String 용량, String 사용인원,  int 금액){
        this.이름=이름;
        this.용량=용량;
        this.사용인원=사용인원;
        this.금액=금액;
    }

}
