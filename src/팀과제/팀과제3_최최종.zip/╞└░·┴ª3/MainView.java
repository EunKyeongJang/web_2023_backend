package 팀과제.팀과제3;

public class MainView {//class start



    public static void main(String[] args) {
        MemberView.getInstance().run();
    }

}//class end


