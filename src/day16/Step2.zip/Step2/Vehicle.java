package day16.Step2;

public interface Vehicle {
    //추상메소드
    void run(); //
}
