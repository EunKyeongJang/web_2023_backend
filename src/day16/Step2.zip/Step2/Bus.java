package day16.Step2;

public class Bus implements Vehicle{
    //추상메소드 재정의
    public void run(){
        System.out.println("버스가 달립니다.");
    }
}
